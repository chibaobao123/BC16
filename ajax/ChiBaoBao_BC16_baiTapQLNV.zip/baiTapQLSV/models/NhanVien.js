//Tạo ra kiểu dữ liệu (prototype | class ) để lưu trữ thông tin từ giao diện
function NhanVien() {
  this.maNhanVien = 0;
  this.tenNhanVien = "";
  this.chucVu = "";
  this.heSoChucVu = 0;
  this.luongCoBan = 0;
  this.soGioLamTrongThang = 0;
}
